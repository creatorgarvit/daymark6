-- Update existing Supabase projects with: supabase db push
-- Each user can only read and modify their own planner tasks.
create table if not exists public.planner_tasks (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users (id) on delete cascade,
  title text not null check (char_length(title) between 1 and 140),
  task_date date not null,
  task_time time,
  category text not null default 'Focus' check (category in ('Focus', 'Study', 'Personal')),
  completed boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index if not exists planner_tasks_user_date_idx
  on public.planner_tasks (user_id, task_date, task_time);

alter table public.planner_tasks enable row level security;

drop policy if exists "Users can read their own planner tasks" on public.planner_tasks;
create policy "Users can read their own planner tasks"
  on public.planner_tasks for select to authenticated using ((select auth.uid()) = user_id);

drop policy if exists "Users can create their own planner tasks" on public.planner_tasks;
create policy "Users can create their own planner tasks"
  on public.planner_tasks for insert to authenticated with check ((select auth.uid()) = user_id);

drop policy if exists "Users can update their own planner tasks" on public.planner_tasks;
create policy "Users can update their own planner tasks"
  on public.planner_tasks for update to authenticated
  using ((select auth.uid()) = user_id) with check ((select auth.uid()) = user_id);

drop policy if exists "Users can delete their own planner tasks" on public.planner_tasks;
create policy "Users can delete their own planner tasks"
  on public.planner_tasks for delete to authenticated using ((select auth.uid()) = user_id);

grant select, insert, update, delete on public.planner_tasks to authenticated;
