"use client";

import { createClient } from "@/lib/supabase/client";
import { hasEnvVars } from "@/lib/utils";
import { ArrowDown, ArrowLeft, ArrowRight, ArrowUpRight, Check, ChevronDown, Circle, Clock3, Cloud, Flower2, Leaf, Plus, Sparkles, Sun, Trash2 } from "lucide-react";
import Link from "next/link";
import { FormEvent, useEffect, useMemo, useState } from "react";

type PlannerTask = {
  id: string;
  title: string;
  date: string;
  time: string;
  category: "Focus" | "Study" | "Personal";
  completed: boolean;
};

const STORAGE_KEY = "narroyen-planner-tasks-v1";
const categories: PlannerTask["category"][] = ["Focus", "Study", "Personal"];

function dateKey(date: Date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}
function startOfWeek(date: Date) {
  const result = new Date(date);
  result.setDate(result.getDate() - ((result.getDay() + 6) % 7));
  result.setHours(0, 0, 0, 0);
  return result;
}
function prettyDate(date: Date, options: Intl.DateTimeFormatOptions) {
  return new Intl.DateTimeFormat("en", options).format(date);
}

const starterTasks: PlannerTask[] = [
  { id: "sample-1", title: "Plan the week with intention", date: dateKey(new Date()), time: "09:00", category: "Focus", completed: false },
  { id: "sample-2", title: "Read 20 pages", date: dateKey(new Date()), time: "11:30", category: "Study", completed: false },
  { id: "sample-3", title: "Take a proper lunch break", date: dateKey(new Date()), time: "13:00", category: "Personal", completed: false },
];

export function PlannerApp() {
  const [selectedDate, setSelectedDate] = useState(() => dateKey(new Date()));
  const [tasks, setTasks] = useState<PlannerTask[]>([]);
  const [hydrated, setHydrated] = useState(false);
  const [userEmail, setUserEmail] = useState<string | null>(null);
  const [draft, setDraft] = useState("");
  const [draftTime, setDraftTime] = useState("");
  const [draftCategory, setDraftCategory] = useState<PlannerTask["category"]>("Focus");
  const [adding, setAdding] = useState(false);
  const [notice, setNotice] = useState("");
  const supabaseEnabled = Boolean(hasEnvVars);

  useEffect(() => {
    try {
      const saved = window.localStorage.getItem(STORAGE_KEY);
      setTasks(saved ? JSON.parse(saved) as PlannerTask[] : starterTasks);
    } catch {
      setTasks(starterTasks);
    }
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (!hydrated) return;
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(tasks));
  }, [tasks, hydrated]);

  useEffect(() => {
    if (!supabaseEnabled) return;
    let active = true;
    const supabase = createClient();
    void (async () => {
      const { data: { user } } = await supabase.auth.getUser();
      if (!active) return;
      setUserEmail(user?.email ?? null);
      if (!user) return;
      const { data, error } = await supabase.from("planner_tasks").select("id,title,task_date,task_time,category,completed").order("created_at");
      if (!active || error || !data) return;
      const remoteTasks = data.map((row) => ({
        id: row.id as string,
        title: row.title as string,
        date: row.task_date as string,
        time: (row.task_time as string | null) ?? "",
        category: row.category as PlannerTask["category"],
        completed: row.completed as boolean,
      }));
      setTasks(remoteTasks);
    })();
    return () => { active = false; };
  }, [supabaseEnabled]);

  const activeDate = useMemo(() => new Date(`${selectedDate}T12:00:00`), [selectedDate]);
  const weekStart = useMemo(() => startOfWeek(activeDate), [activeDate]);
  const weekDays = useMemo(() => Array.from({ length: 7 }, (_, index) => {
    const date = new Date(weekStart);
    date.setDate(weekStart.getDate() + index);
    return date;
  }), [weekStart]);
  const todaysTasks = tasks.filter((task) => task.date === selectedDate);
  const doneCount = todaysTasks.filter((task) => task.completed).length;
  const progress = todaysTasks.length ? Math.round((doneCount / todaysTasks.length) * 100) : 0;

  async function saveRemote(task: PlannerTask) {
    if (!supabaseEnabled || !userEmail) return;
    const supabase = createClient();
    const { error } = await supabase.from("planner_tasks").upsert({
      id: task.id,
      title: task.title,
      task_date: task.date,
      task_time: task.time || null,
      category: task.category,
      completed: task.completed,
    });
    if (error) setNotice("Saved on this device. Cloud sync needs your Supabase table configured.");
  }

  function addTask(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const title = draft.trim();
    if (!title) return;
    const task: PlannerTask = {
      id: crypto.randomUUID(), title, date: selectedDate,
      time: draftTime, category: draftCategory, completed: false,
    };
    setTasks((current) => [...current, task]);
    void saveRemote(task);
    setDraft(""); setDraftTime(""); setAdding(false);
    setNotice("A little progress, one task at a time.");
    window.setTimeout(() => setNotice(""), 2800);
  }

  function toggleTask(task: PlannerTask) {
    const updated = { ...task, completed: !task.completed };
    setTasks((current) => current.map((item) => item.id === task.id ? updated : item));
    void saveRemote(updated);
  }

  function carryOver() {
    const unfinished = todaysTasks.filter((task) => !task.completed);
    if (!unfinished.length) return;
    const tomorrow = new Date(`${selectedDate}T12:00:00`);
    tomorrow.setDate(tomorrow.getDate() + 1);
    const nextDay = dateKey(tomorrow);
    const carried = unfinished.map((task) => ({ ...task, id: crypto.randomUUID(), date: nextDay }));
    setTasks((current) => [...current, ...carried]);
    carried.forEach((task) => void saveRemote(task));
    setNotice(`${carried.length} ${carried.length === 1 ? "task" : "tasks"} carried into tomorrow.`);
    window.setTimeout(() => setNotice(""), 2800);
  }

  async function removeTask(task: PlannerTask) {
    setTasks((current) => current.filter((item) => item.id !== task.id));
    if (supabaseEnabled && userEmail) {
      const supabase = createClient();
      await supabase.from("planner_tasks").delete().eq("id", task.id);
    }
  }

  function shiftDate(days: number) {
    const date = new Date(`${selectedDate}T12:00:00`);
    date.setDate(date.getDate() + days);
    setSelectedDate(dateKey(date));
  }

  return (
    <main className="planner-shell">
      <aside className="sidebar">
        <Link href="/" className="brand" aria-label="Narroyen home"><span className="brand-mark"><Flower2 size={21} /></span><span>narroyen<span className="brand-period">.</span></span></Link>
        <div className="sidebar-section-label">YOUR SPACE</div>
        <button className="side-link side-link-active"><Sun size={17} /> Today <span className="side-count">{todaysTasks.filter((task) => !task.completed).length || "—"}</span></button>
        <button className="side-link" onClick={() => setSelectedDate(dateKey(new Date()))}><Clock3 size={17} /> Upcoming</button>
        <div className="sidebar-section-label sidebar-label-later">COLLECTIONS</div>
        <button className="side-link" onClick={() => { setDraftCategory("Study"); setAdding(true); }}><span className="collection-dot study-dot" /> Study & revision</button>
        <button className="side-link" onClick={() => { setDraftCategory("Personal"); setAdding(true); }}><span className="collection-dot personal-dot" /> Personal</button>
        <div className="sidebar-bottom">
          <div className="sidebar-note"><Sparkles size={16} /><p>A gentle reminder: you don’t have to do it all at once.</p></div>
          <div className="profile-row"><div className="avatar">{userEmail ? userEmail[0].toUpperCase() : "N"}</div><div className="profile-text"><strong>{userEmail ? userEmail.split("@")[0] : "Your notebook"}</strong><span>{userEmail ? "Synced account" : "Just for you"}</span></div>{supabaseEnabled && <Link href={userEmail ? "/protected" : "/auth/login"} className="profile-action" aria-label={userEmail ? "Account" : "Sign in"}><ArrowUpRight size={16} /></Link>}</div>
        </div>
      </aside>

      <section className="main-panel">
        <header className="topbar"><div className="breadcrumb">MY PLANNER <span>/</span> <b>DAILY VIEW</b></div><div className="topbar-right"><span className={`sync-status ${userEmail ? "is-synced" : ""}`}><Cloud size={15} />{userEmail ? "Synced" : "Saved on this device"}</span>{supabaseEnabled && <Link href={userEmail ? "/auth/login" : "/auth/login"} className="signin-link">{userEmail ? "Account" : "Sign in"}<ArrowUpRight size={14} /></Link>}</div></header>

        <div className="content-wrap">
          <div className="welcome-row"><div><div className="eyebrow"><span className="eyebrow-line" /> {prettyDate(activeDate, { weekday: "long", month: "long", day: "numeric" }).toUpperCase()}</div><h1>Your day,<br /><span>in good order.</span></h1><p className="welcome-subtitle">Make space for what matters. The rest can wait.</p></div><div className="sun-illustration"><div className="sun-halo"><Sun size={34} strokeWidth={1.25} /></div><span className="orbit-dot dot-one" /><span className="orbit-dot dot-two" /><span className="orbit-dot dot-three" /></div></div>

          <section className="week-card" aria-label="Choose a day"><div className="week-heading"><span>{prettyDate(weekStart, { month: "long", year: "numeric" })}</span><div className="week-controls"><button onClick={() => shiftDate(-7)} aria-label="Previous week"><ArrowLeft size={16} /></button><button onClick={() => setSelectedDate(dateKey(new Date()))} className="today-control">Today</button><button onClick={() => shiftDate(7)} aria-label="Next week"><ArrowRight size={16} /></button></div></div><div className="week-days">{weekDays.map((day) => { const key = dateKey(day); const selected = key === selectedDate; const isToday = key === dateKey(new Date()); const count = tasks.filter((task) => task.date === key && !task.completed).length; return <button key={key} className={`day-button ${selected ? "day-selected" : ""} ${isToday ? "day-today" : ""}`} onClick={() => setSelectedDate(key)}><span className="day-name">{prettyDate(day, { weekday: "short" })}</span><span className="day-number">{day.getDate()}</span><span className={`day-indicator ${count ? "has-tasks" : ""}`} /></button>; })}</div></section>

          <section className="tasks-section"><div className="section-heading"><div><div className="section-kicker">A GOOD PLACE TO START</div><h2>Today’s rhythm <span className="task-count">{todaysTasks.length}</span></h2></div><button className="add-task-button" onClick={() => setAdding((value) => !value)}><Plus size={17} /> Add a task</button></div>
            <div className="progress-card"><div className="progress-copy"><span className="progress-icon"><Leaf size={17} /></span><div><strong>{todaysTasks.length === 0 ? "A fresh page" : progress === 100 ? "Look at you, all done." : "Small steps still move you forward."}</strong><span>{todaysTasks.length === 0 ? "Add something you’d like to make time for." : `${doneCount} of ${todaysTasks.length} ${todaysTasks.length === 1 ? "task" : "tasks"} complete`}</span></div></div><div className="progress-track"><span style={{ width: `${progress}%` }} /></div><span className="progress-percent">{progress}%</span></div>

            {adding && <form className="add-form" onSubmit={addTask}><label className="sr-only" htmlFor="task-title">Task name</label><input id="task-title" autoFocus value={draft} onChange={(event) => setDraft(event.target.value)} placeholder="What would you like to do?" maxLength={140} required /><label className="sr-only" htmlFor="task-time">Time</label><input id="task-time" aria-label="Optional time" type="time" value={draftTime} onChange={(event) => setDraftTime(event.target.value)} /><label className="sr-only" htmlFor="task-category">Category</label><select id="task-category" value={draftCategory} onChange={(event) => setDraftCategory(event.target.value as PlannerTask["category"])}>{categories.map((category) => <option key={category}>{category}</option>)}</select><button className="form-save" type="submit">Save task</button><button className="form-cancel" type="button" onClick={() => setAdding(false)}>Cancel</button></form>}

            <div className="task-list">{todaysTasks.length ? todaysTasks.slice().sort((a, b) => (a.time || "99:99").localeCompare(b.time || "99:99")).map((task) => <article className={`task-row ${task.completed ? "task-completed" : ""}`} key={task.id}><button className="task-check" onClick={() => toggleTask(task)} aria-label={task.completed ? `Mark ${task.title} incomplete` : `Complete ${task.title}`}>{task.completed ? <span className="check-filled"><Check size={14} /></span> : <Circle size={20} strokeWidth={1.5} />}</button><div className="task-main"><span className="task-title">{task.title}</span><span className="task-meta">{task.time && <><Clock3 size={13} />{task.time}<i /></>}<span className={`category-tag ${task.category.toLowerCase()}`}>{task.category}</span></span></div><button className="delete-task" onClick={() => void removeTask(task)} aria-label={`Delete ${task.title}`}><Trash2 size={16} /></button></article>) : <div className="empty-state"><div className="empty-flower"><Flower2 size={25} /></div><strong>Nothing on the page just yet.</strong><span>That can be a lovely thing. Add a task when you’re ready.</span><button onClick={() => setAdding(true)}><Plus size={15} /> Add your first task</button></div>}</div>

            {todaysTasks.some((task) => !task.completed) && <button className="carry-button" onClick={carryOver}><ArrowDown size={15} /> Carry unfinished tasks to tomorrow</button>}
          </section>

          <footer className="page-footer"><span>Made for a more mindful day <span className="footer-heart">✳</span></span><span>One thing at a time.</span></footer>
        </div>
        {notice && <div role="status" className="notice"><Check size={16} />{notice}<button onClick={() => setNotice("")} aria-label="Dismiss message">×</button></div>}
      </section>
    </main>
  );
}
