# Narroyen

A calm, responsive daily planner built with Next.js, TypeScript, Tailwind CSS, and Supabase. Plan tasks by day, track progress, organize work into Focus, Study, and Personal, and carry unfinished tasks into tomorrow.

## Run locally

1. Install Node.js 20.9 or later and run `npm install`.
2. Copy `.env.example` to `.env.local`.
3. Run `npm run dev` and open [http://localhost:3000](http://localhost:3000).

The planner works immediately and saves tasks in the current browser. For accounts and cloud sync, create a Supabase project, set the two public environment variables from `.env.local`, and apply the database migration in `supabase/migrations/20261119000000_create_planner_tasks.sql` (for example with the Supabase CLI: `supabase db push`). The existing sign-up and sign-in pages provide email/password authentication. Once signed in, the app loads and syncs tasks through Supabase with row-level security so each user can access only their own rows.

```env
NEXT_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=your-supabase-publishable-key
```

Never put a Supabase service-role key in browser code or commit secrets. The publishable key is intended for client use; database access is restricted by the migration's RLS policies.

## Deploy

Import the repository into Vercel, add the same environment variables in the project settings, and deploy. Add a custom domain from Vercel's domain settings when you have one. Configure the domain in Supabase Auth's allowed redirect URLs for production sign-in links.
